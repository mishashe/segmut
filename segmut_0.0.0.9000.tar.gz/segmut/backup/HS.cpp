// #include <Rcpp.h>
#include <iostream>
#include <random>
#include <chrono>
#include <math.h>
#include <stdint.h>

// [[Rcpp::depends(RcppArmadillo)]]
#define ARMA_WARN_LEVEL 0
#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;
using namespace std;

// [[Rcpp::export]]
double getChiSquare(rowvec par, uvec& muts, double& L)
{
  double chiSquare = 0;
  double density = (double)muts.n_rows / (double)L;
  double expected;
  int imuts = 0;
  int ipar;
  int nmuts = 0;

  for (ipar = 1; ipar < par.n_cols; ipar++)
  {
    nmuts = 0;
    while (imuts<muts.n_rows && muts(imuts) < par(ipar))
    {
      nmuts++;
      imuts++;
    }
    expected = density*(par(ipar)-par(ipar-1)+1);
    chiSquare += (nmuts - expected)*(nmuts - expected)/expected;
  }
  return(chiSquare);
}

// [[Rcpp::export]]
long int getBestSingleBreak(uvec& muts, double& L, rowvec& parPrev)
{
  double expected;
  double expected1;
  double expected2;
  double bestChiSquareDiff = log((double)muts.n_rows);
  double ChiSquare;
  double ChiSquare1;
  double ChiSquare2;
  long int xBest=0;
  double density = (double)muts.n_rows / (double)L;

  int nmuts = 0;
  int imuts = 0;
  int ipar = 0;
  int imutsx = 0;
  int nmutsx = 0;
  for (ipar = 1; ipar < parPrev.n_cols; ipar++)
  {
    nmuts = 0;
    while (imuts<muts.n_rows && muts(imuts) < parPrev(ipar))
    {
      nmuts++;
      imuts++;
    }
    expected = density*(parPrev(ipar)-parPrev(ipar-1)+1);
    ChiSquare = (nmuts - expected)*(nmuts - expected)/expected;
    nmutsx = 0;
    for (long int x = parPrev(ipar-1); x <= parPrev(ipar); x++)
    {
      while (imutsx<muts.n_rows && muts(imutsx) < x)
      {
        nmutsx++;
        imutsx++;
      }
      if (x > parPrev(ipar-1) + 10 && x < parPrev(ipar)-10 && nmuts>5)
      {
        expected1 = density*(x-parPrev(ipar-1)+1);
        ChiSquare1 = (nmutsx - expected1)*(nmutsx - expected1)/expected1;
        expected2 = density*(parPrev(ipar) - x + 1);
        ChiSquare2 = (nmuts - nmutsx - expected2)*(nmuts - nmutsx - expected2)/expected2;
        if (ChiSquare1 + ChiSquare2 - ChiSquare > bestChiSquareDiff)
        {
          bestChiSquareDiff = ChiSquare1 + ChiSquare2 - ChiSquare;
          xBest = x;
        }
      }
    }
  }
  return(xBest);
}



// [[Rcpp::export]]
rowvec doHSpop(uvec& muts, double& L, mat pop)
{
  double HMCR = 0.95;
  double PAR = 0.3;

  int N = pop.n_cols;
  int P = pop.n_rows;

  rowvec newHarmony(N);

  int n;
  int p;

  std::random_device dev;
  std::mt19937 rngP(dev());
  std::uniform_int_distribution<std::mt19937::result_type> distP(0,P-1); // distribution in range [0, P-1]

  std::default_random_engine generator;
  std::uniform_real_distribution<double> distribution(0.0,1.0);

  vec values(P);
  for (p = 0; p < P; p++) values(p) = getChiSquare(pop.row(p), muts, L);


  int worstHarmony  = values.index_min();
  double worstValue = values(worstHarmony);

  int t = 0;
  int runNoChange = 0;
  while(t<100 || runNoChange<100)
  {
    for (n = 0; n < N; n++)
    {
      if(distribution(generator) < HMCR) // get new position from random harmony memory
      {
        newHarmony(n) = pop(distP(rngP),n);
        if(distribution(generator) < PAR) // adjust pitch based on random values
        {
          double temp = newHarmony(n) + 10*(distribution(generator)-0.5);
          if(temp >= 0 && temp <= L) newHarmony(n) = temp;
        }
      }
      else // get new position from random value
      {
        newHarmony(n) = L*distribution(generator);
      }
    }
    newHarmony = sort(newHarmony);

    double Value = getChiSquare(newHarmony, muts, L);
    if (Value > worstValue)
    {
      runNoChange = 0;
      pop.row(worstHarmony) = newHarmony;
      values(worstHarmony) = Value;
      worstHarmony  = values.index_min();
      worstValue = values(worstHarmony);
    }
    t++;
    runNoChange++;
    //Rcout<<worstValue<<endl;
  }

  int bestHarmony = values.index_max();
  return (pop.row(bestHarmony));
}

// [[Rcpp::export]]
rowvec improve(uvec& muts, double& L, rowvec par)
{
  double lognmuts = log((double)muts.n_rows);
  double ChiSquareBest = -1000.0;
  int runs=0;
  std::random_device dev;
  std::mt19937 rng(dev());
  std::uniform_int_distribution<std::mt19937::result_type> dist(0,1e6); // distribution in range
  long int newPos;

  newPos = getBestSingleBreak(muts, L, par);
  if (newPos==0 && par.n_cols==2) //cannot add even a single break
  {
    return(par);
  }


  while (runs < 10)
  {
    newPos = getBestSingleBreak(muts, L, par);
    if (newPos!=0) //add one break
    {
      rowvec parAdded(par.n_cols+1);
      for (int i=0; i<par.n_cols; i++) parAdded(i) = par(i);
      parAdded(par.n_cols)=newPos;
      par = sort(parAdded);
    }

    int Ind = 1 + (dist(rng) % (par.n_cols-2));
    rowvec parRemoved(par.n_cols-1);
    for (int i=0;i<Ind;i++) parRemoved(i) = par(i);
    for (int i=Ind+1;i<par.n_cols;i++) parRemoved(i-1) = par(i);
    newPos = getBestSingleBreak(muts, L, parRemoved);
    if (newPos==0) //remove one break
    {
      par = parRemoved;
    }
    else if (newPos!=par(Ind))  //move one break
    {
      par(Ind) = newPos;
      par = sort(par);
    }
    double ChiSquare = getChiSquare(par, muts, L) - (par.n_cols-2.0)*lognmuts;
    if (ChiSquare > ChiSquareBest)
    {
      ChiSquareBest = ChiSquare;
      runs = 0;
    }
    runs++;
  }
  return(par);
}

// [[Rcpp::export]]
rowvec doHS(uvec& muts, double& L)
{
  long int x = 100;
  rowvec popBest(2);
  popBest(0) = 0;
  popBest(1) = L+1;
  while (x!=0)
  {
    x = getBestSingleBreak(muts, L, popBest);
    if (x==0) {return(popBest);}
    else
    {
      popBest.insert_cols(popBest.n_cols, 1);
      popBest(popBest.n_cols-1)=x;
      popBest = sort(popBest);
      popBest = improve(muts, L, popBest);
    }
  }
  return(popBest);
}











